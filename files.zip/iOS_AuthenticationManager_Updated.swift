// AuthenticationManager.swift
// Lina'la iOS - Real Backend Authentication

import Foundation
import Combine

@MainActor
class AuthenticationManager: ObservableObject {
    @Published var isAuthenticated = false
    @Published var currentUser: UserProfile?
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    private var cancellables = Set<AnyCancellable>()
    
    init() {
        checkAuthStatus()
    }
    
    // MARK: - Authentication Methods
    
    func login(email: String, password: String) async {
        isLoading = true
        errorMessage = nil
        
        do {
            let response = try await APIService.shared.login(email: email, password: password)
            currentUser = response.user
            isAuthenticated = true
            isLoading = false
        } catch let error as APIError {
            errorMessage = error.localizedDescription
            isLoading = false
        } catch {
            errorMessage = "An unexpected error occurred"
            isLoading = false
        }
    }
    
    func register(email: String, password: String) async {
        isLoading = true
        errorMessage = nil
        
        do {
            let response = try await APIService.shared.register(email: email, password: password)
            currentUser = response.user
            isAuthenticated = true
            isLoading = false
        } catch let error as APIError {
            errorMessage = error.localizedDescription
            isLoading = false
        } catch {
            errorMessage = "An unexpected error occurred"
            isLoading = false
        }
    }
    
    func logout() {
        APIService.shared.logout()
        currentUser = nil
        isAuthenticated = false
    }
    
    // MARK: - Helper Methods
    
    private func checkAuthStatus() {
        // Check if tokens exist in UserDefaults
        if let _ = UserDefaults.standard.string(forKey: "accessToken") {
            // Token exists, try to fetch user profile
            Task {
                do {
                    let patient = try await APIService.shared.getPatientProfile()
                    // Convert patient to UserProfile (simplified)
                    currentUser = UserProfile(
                        id: patient.userId,
                        email: "", // Not returned from patient endpoint
                        role: "PATIENT",
                        clinicId: patient.clinicId,
                        patientId: patient.id,
                        providerId: nil
                    )
                    isAuthenticated = true
                } catch {
                    // Token invalid, logout
                    logout()
                }
            }
        }
    }
}

// MARK: - Validation Extensions

extension AuthenticationManager {
    func validateEmail(_ email: String) -> Bool {
        let emailRegex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegex)
        return emailPred.evaluate(with: email)
    }
    
    func validatePassword(_ password: String) -> Bool {
        return password.count >= 6
    }
}
