// ViewModels_Updated.swift
// Lina'la iOS - Real Backend Data Integration

import Foundation
import Combine

// MARK: - Home View Model

@MainActor
class HomeViewModel: ObservableObject {
    @Published var patientProfile: PatientResponse?
    @Published var analytics: PatientAnalytics?
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    func loadDashboardData() async {
        isLoading = true
        errorMessage = nil
        
        do {
            // Fetch patient profile
            let profile = try await APIService.shared.getPatientProfile()
            patientProfile = profile
            
            // Fetch analytics (HRV, recovery score, etc.)
            let analyticsData = try await APIService.shared.getPatientAnalytics()
            analytics = analyticsData
            
            isLoading = false
        } catch let error as APIError {
            errorMessage = error.localizedDescription
            isLoading = false
        } catch {
            errorMessage = "Failed to load dashboard data"
            isLoading = false
        }
    }
    
    // Computed properties for UI
    var displayName: String {
        if let first = patientProfile?.firstName, let last = patientProfile?.lastName {
            return "\(first) \(last)"
        }
        return "Welcome"
    }
    
    var recoveryScore: Double {
        analytics?.recoveryScore ?? 0
    }
    
    var stressLevel: String {
        analytics?.stressLevel ?? "unknown"
    }
    
    var currentHeartRate: Int? {
        analytics?.latestVitals?.heartRate
    }
    
    var currentBloodPressure: String? {
        guard let systolic = analytics?.latestVitals?.systolicBP,
              let diastolic = analytics?.latestVitals?.diastolicBP else {
            return nil
        }
        return "\(systolic)/\(diastolic)"
    }
}

// MARK: - Vitals View Model

@MainActor
class VitalsViewModel: ObservableObject {
    @Published var measurements: [MeasurementResponse] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    private var patientId: String?
    
    func setPatientId(_ id: String) {
        self.patientId = id
    }
    
    func loadVitals() async {
        guard let patientId = patientId else { return }
        
        isLoading = true
        errorMessage = nil
        
        do {
            let vitals = try await APIService.shared.getMeasurements(patientId: patientId)
            measurements = vitals
            isLoading = false
        } catch let error as APIError {
            errorMessage = error.localizedDescription
            isLoading = false
        } catch {
            errorMessage = "Failed to load vitals"
            isLoading = false
        }
    }
    
    func logVital(type: String, value: MeasurementValue) async {
        guard let patientId = patientId else { return }
        
        isLoading = true
        errorMessage = nil
        
        do {
            let newVital = try await APIService.shared.logMeasurement(
                patientId: patientId,
                type: type,
                value: value,
                timestamp: Date(),
                source: "MANUAL"
            )
            
            // Add to local array
            measurements.insert(newVital, at: 0)
            isLoading = false
        } catch let error as APIError {
            errorMessage = error.localizedDescription
            isLoading = false
        } catch {
            errorMessage = "Failed to log vital"
            isLoading = false
        }
    }
    
    // Filter methods for different vital types
    func bloodPressureReadings() -> [MeasurementResponse] {
        measurements.filter { $0.type == "BLOOD_PRESSURE" }
    }
    
    func glucoseReadings() -> [MeasurementResponse] {
        measurements.filter { $0.type == "GLUCOSE" }
    }
    
    func weightReadings() -> [MeasurementResponse] {
        measurements.filter { $0.type == "WEIGHT" }
    }
    
    func hrvReadings() -> [HRVTrendPoint] {
        // Get from analytics endpoint instead
        []
    }
}

// MARK: - Medications View Model

@MainActor
class MedicationsViewModel: ObservableObject {
    @Published var medications: [Medication] = []
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    // For Phase 2: Connect to medication endpoint
    // For now, using local mock data until medication endpoints are added
    
    func loadMedications() async {
        isLoading = true
        
        // Mock data for now
        medications = [
            Medication(
                id: "1",
                name: "Metformin",
                dosage: "500mg",
                frequency: "Twice daily",
                lastTaken: Date()
            ),
            Medication(
                id: "2",
                name: "Lisinopril",
                dosage: "10mg",
                frequency: "Once daily",
                lastTaken: Date().addingTimeInterval(-86400)
            )
        ]
        
        isLoading = false
    }
    
    func markAsTaken(medicationId: String) {
        if let index = medications.firstIndex(where: { $0.id == medicationId }) {
            medications[index].lastTaken = Date()
        }
    }
}

// MARK: - Messages View Model

@MainActor
class MessagesViewModel: ObservableObject {
    @Published var threads: [MessageThreadResponse] = []
    @Published var currentThread: MessageThreadResponse?
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    func loadThreads() async {
        isLoading = true
        errorMessage = nil
        
        do {
            let fetchedThreads = try await APIService.shared.getMessageThreads()
            threads = fetchedThreads
            isLoading = false
        } catch let error as APIError {
            errorMessage = error.localizedDescription
            isLoading = false
        } catch {
            errorMessage = "Failed to load messages"
            isLoading = false
        }
    }
    
    func loadThread(threadId: String) async {
        isLoading = true
        errorMessage = nil
        
        do {
            let thread = try await APIService.shared.getThread(threadId: threadId)
            currentThread = thread
            isLoading = false
        } catch let error as APIError {
            errorMessage = error.localizedDescription
            isLoading = false
        } catch {
            errorMessage = "Failed to load thread"
            isLoading = false
        }
    }
    
    func sendMessage(threadId: String, content: String) async {
        isLoading = true
        errorMessage = nil
        
        do {
            let newMessage = try await APIService.shared.sendMessage(threadId: threadId, content: content)
            
            // Add to current thread
            if var thread = currentThread, thread.id == threadId {
                var messages = thread.messages ?? []
                messages.append(newMessage)
                thread.messages = messages
                currentThread = thread
            }
            
            isLoading = false
        } catch let error as APIError {
            errorMessage = error.localizedDescription
            isLoading = false
        } catch {
            errorMessage = "Failed to send message"
            isLoading = false
        }
    }
}

// MARK: - Profile View Model

@MainActor
class ProfileViewModel: ObservableObject {
    @Published var patient: PatientResponse?
    @Published var isLoading = false
    @Published var errorMessage: String?
    
    func loadProfile() async {
        isLoading = true
        errorMessage = nil
        
        do {
            let profile = try await APIService.shared.getPatientProfile()
            patient = profile
            isLoading = false
        } catch let error as APIError {
            errorMessage = error.localizedDescription
            isLoading = false
        } catch {
            errorMessage = "Failed to load profile"
            isLoading = false
        }
    }
}

// MARK: - Supporting Models

struct Medication: Identifiable {
    let id: String
    let name: String
    let dosage: String
    let frequency: String
    var lastTaken: Date?
}
