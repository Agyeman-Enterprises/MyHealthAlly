# 🎯 TODAY'S ACTION PLAN - FINISH iOS DEPLOYMENT

**Date:** November 23, 2025  
**Goal:** Complete Lina'la iOS Phase 2 → TestFlight Deployment  
**Timeline:** Today (8-10 hours of focused work)  

---

## 🚨 CRITICAL UNDERSTANDING

### What You DON'T Do
❌ **NO manual coding**  
❌ **NO file editing**  
❌ **NO command-line work**  
❌ **NO debugging**  

### What You DO Do
✅ **Answer strategic questions** (when I ask)  
✅ **Approve milestones** (when I show you)  
✅ **Test in Xcode** (when Henry's ready)  
✅ **Make final decisions** (architecture choices)  

**Everything else = Automated by Claude + Cursor**

---

## 📋 PHASE 2: BACKEND INTEGRATION (Steps 1-5)

### Step 1: Get Backend Information from Cursor ⏱️ 5 minutes

**I need you to paste these 3 prompts into Cursor EXACTLY:**

#### Prompt 1: Backend Status
```
What is the current status of the NestJS backend? Please provide:
1. Is it running? On what port?
2. What is the base URL? (localhost:3000? deployed URL?)
3. Are these endpoints working:
   - POST /auth/login
   - POST /auth/register
   - GET /patients/me
   - GET /vitals
   - POST /vitals
4. What is the JWT token structure?
5. Show me the current .env file (redact sensitive values)

Save response to: /docs/BACKEND_STATUS.md
```

#### Prompt 2: API Endpoint Reference
```
Generate complete API documentation for all endpoints including:
- Authentication (login, register, refresh, logout)
- Patient endpoints (profile, vitals, medications, messages)
- Request/response TypeScript interfaces
- Error response formats
- Example requests with curl commands

Save to: /docs/API_REFERENCE.md
```

#### Prompt 3: Environment Configuration
```
List all environment variables needed for:
1. Backend (.env)
2. Frontend (.env.local)
3. Mobile app (will need API_BASE_URL)

Include example values and descriptions.

Save to: /docs/ENV_CONFIG.md
```

**After running these, copy/paste the 3 generated markdown files to me.**

---

### Step 2: iOS Backend Service Layer ⏱️ 30 minutes

**I will create (you do nothing):**

```swift
// APIService.swift - Main API client
class APIService {
    static let shared = APIService()
    private let baseURL = "YOUR_BACKEND_URL"  // From Cursor's response
    
    func login(email: String, password: String) async throws -> AuthResponse
    func register(userData: RegisterRequest) async throws -> AuthResponse
    func getPatientProfile() async throws -> Patient
    func getVitals() async throws -> [Vital]
    func logVital(vital: VitalLog) async throws -> Vital
    func getMedications() async throws -> [Medication]
    func getMessages() async throws -> [Message]
    func sendMessage(content: String) async throws -> Message
}

// AuthManager.swift - Updated with real API
class AuthManager: ObservableObject {
    @Published var isAuthenticated = false
    @Published var currentUser: User?
    
    func login(email: String, password: String) async throws {
        let response = try await APIService.shared.login(email: email, password: password)
        // Store JWT token
        // Update authentication state
    }
}

// NetworkManager.swift - Handles requests/errors
class NetworkManager {
    func request<T: Decodable>(...) async throws -> T
    func handleError(_ error: Error) -> UserFriendlyError
}
```

---

### Step 3: Replace Mock Data with Real API ⏱️ 45 minutes

**Files I'll update:**

1. **HomeViewModel.swift**
   - ❌ Remove: Mock streak data
   - ✅ Add: `await APIService.shared.getPatientProfile()`
   - ✅ Add: Real-time task fetching

2. **VitalsViewModel.swift**
   - ❌ Remove: Mock vitals array
   - ✅ Add: `await APIService.shared.getVitals()`
   - ✅ Add: `await APIService.shared.logVital()`

3. **MedicationsViewModel.swift**
   - ❌ Remove: Mock medication list
   - ✅ Add: `await APIService.shared.getMedications()`
   - ✅ Add: Real medication logging

4. **MessagesViewModel.swift**
   - ❌ Remove: Mock message thread
   - ✅ Add: `await APIService.shared.getMessages()`
   - ✅ Add: Real-time message sending

---

### Step 4: HealthKit Integration ⏱️ 30 minutes

**I'll update HealthKitManager.swift:**

```swift
class HealthKitManager: ObservableObject {
    // Request permissions (already exists)
    func requestAuthorization() async throws
    
    // NEW: Auto-sync to backend
    func startBackgroundSync() {
        // Every 30 minutes, sync recent vitals to API
        Timer.publish(every: 1800, on: .main, in: .common)
            .autoconnect()
            .sink { [weak self] _ in
                Task { await self?.syncToBackend() }
            }
    }
    
    func syncToBackend() async {
        let vitals = try await readRecentVitals()
        for vital in vitals {
            try await APIService.shared.logVital(vital)
        }
    }
}
```

**Info.plist additions:**
```xml
<key>NSHealthShareUsageDescription</key>
<string>Lina'la needs access to read your health data to track your wellness journey.</string>
<key>NSHealthUpdateUsageDescription</key>
<string>Lina'la will store your health data in Apple Health for your records.</string>
```

---

### Step 5: Authentication Flow ⏱️ 30 minutes

**Update these views:**

1. **SignInView.swift**
   - Wire up real login button
   - Show loading state
   - Handle errors (wrong password, network issues)
   - Navigate to home on success

2. **SignUpView.swift**
   - Wire up real registration
   - Validate fields (email format, password strength)
   - Show loading state
   - Auto-login after registration

3. **App/LinalaApp.swift**
   - Check for saved JWT token on launch
   - Auto-login if token valid
   - Show onboarding if new user

---

## 🧪 PHASE 3: TESTING (Steps 6-7)

### Step 6: Simulator Testing ⏱️ 30 minutes

**I'll create a test checklist for Henry:**

```markdown
## iOS Simulator Testing Checklist

### Authentication
- [ ] Sign up with new account
- [ ] Login with existing account
- [ ] Wrong password shows error
- [ ] Network error shows friendly message
- [ ] Token persists across app restarts

### Home Dashboard
- [ ] Streak counter shows correct days
- [ ] Tasks load from backend
- [ ] Refresh pulls new data
- [ ] Navigation to other screens works

### Vitals Tracking
- [ ] List shows all vitals from backend
- [ ] Can log new vital (BP, glucose, weight)
- [ ] New vital appears immediately
- [ ] Charts render correctly
- [ ] HealthKit sync button works

### Medications
- [ ] List loads from backend
- [ ] Can mark dose as taken
- [ ] Refill request button works
- [ ] Medication details show correctly

### Messages
- [ ] Thread loads from backend
- [ ] Can send new message
- [ ] Messages appear in real-time
- [ ] Provider responses show

### Profile
- [ ] Profile data loads
- [ ] Can update profile info
- [ ] Settings save correctly
- [ ] Sign out works
```

**Henry runs this in Simulator, reports any issues.**

---

### Step 7: Device Testing (iPhone) ⏱️ 1 hour

**Once connectivity resolved:**

1. **Provisioning Profile Setup**
   - Generate development provisioning profile
   - Download to Xcode
   - Select correct team/certificate

2. **Build for Device**
   - Connect iPhone via cable
   - Select device in Xcode
   - Build and run (⌘ + R)
   - Grant permissions when prompted

3. **Real Device Testing**
   - Test HealthKit (Simulator can't do this)
   - Test push notifications
   - Test camera permissions (future feature)
   - Verify performance on real hardware

---

## 🚀 PHASE 4: TESTFLIGHT DEPLOYMENT (Steps 8-10)

### Step 8: App Store Connect Setup ⏱️ 20 minutes

**You (or Henry) do this once in browser:**

1. Go to: https://appstoreconnect.apple.com
2. Sign in with Apple Developer account
3. Click "My Apps" → "+" → "New App"
4. Settings:
   ```
   Name: Lina'la
   Primary Language: English (U.S.)
   Bundle ID: com.ohimaa.linala (from dropdown)
   SKU: LINALA001
   User Access: Full Access
   ```
5. Save

**I'll need the App ID that gets generated (e.g., 1234567890)**

---

### Step 9: Archive & Upload ⏱️ 30 minutes

**Henry does in Xcode:**

1. Select "Any iOS Device (arm64)" as build target
2. Product → Archive (⌘ + B then Archive)
3. Wait for archive to complete (~5 min)
4. When Organizer opens:
   - Select the archive
   - Click "Distribute App"
   - Choose "App Store Connect"
   - Select "Upload"
   - Follow prompts (auto-signing recommended)
5. Upload completes → Shows in App Store Connect

**Wait 10-15 minutes for Apple processing**

---

### Step 10: TestFlight Setup ⏱️ 15 minutes

**In App Store Connect:**

1. Go to your app → TestFlight tab
2. Build appears (after processing)
3. Click build → Provide export compliance info:
   ```
   Does your app use encryption? NO
   (Unless using custom crypto beyond standard HTTPS)
   ```
4. Add Internal Testers:
   - Henry's Apple ID
   - Your Apple ID
   - Up to 100 internal testers
5. Click "Start Testing"

**Testers receive email → Download TestFlight app → Install Lina'la**

---

## ✅ COMPLETION CRITERIA

### You'll Know We're Done When:

1. ✅ Backend API endpoints all working
2. ✅ iOS app authenticates with real accounts
3. ✅ All mock data replaced with API calls
4. ✅ HealthKit syncing vitals to backend
5. ✅ Simulator testing checklist 100% passed
6. ✅ Device testing (if iPhone available) passed
7. ✅ TestFlight build uploaded successfully
8. ✅ You and Henry can install from TestFlight
9. ✅ App runs perfectly on real iPhones
10. ✅ Ready for patient onboarding

---

## 🔄 MY WORKFLOW (Automated)

### For Each Code Change:

```bash
# 1. I write the Swift code
# 2. I test compilation
# 3. I commit to version control
# 4. I document changes
# 5. I notify you of milestone
```

**You never see the individual commits - just the milestones.**

---

## 📞 WHEN I'LL UPDATE YOU

### Automatic Updates:
- ✅ "Step 2 complete: Backend service layer created"
- ✅ "Step 3 complete: Mock data replaced with real API"
- ✅ "Step 5 complete: Authentication flow wired up"
- ✅ "Ready for Henry to test in Simulator"
- ✅ "Ready for TestFlight upload"

### Questions I'll Ask:
- "Backend URL from Cursor is X - confirm this is correct?"
- "Should I use staging or production backend?"
- "TestFlight internal testers: add who besides you and Henry?"

---

## ⚠️ POTENTIAL BLOCKERS

### If Backend Not Running:
**Fallback:** I'll create a minimal Express.js mock API so iOS can proceed

### If iPhone Connectivity Issues Persist:
**Fallback:** Skip Step 7, go straight to TestFlight with Simulator-only testing

### If TestFlight Upload Fails:
**Common causes:**
- Missing provisioning profile → I'll generate
- Invalid entitlements → I'll fix
- App Store Connect not set up → You/Henry set up

**I'll troubleshoot and provide exact instructions**

---

## 🎯 START COMMAND

**When you're ready, just paste the 3 Cursor prompts from Step 1.**

After you give me those 3 documents, I'll say:

**"🚀 Backend info received. Starting Phase 2 implementation now. Estimated completion: [TIME]. I'll update you at each milestone."**

Then I execute Steps 2-10 with zero further input from you (except approvals).

---

## 📊 ESTIMATED TIMELINE

```
Step 1: Get backend info          →  5 min (you paste prompts)
Step 2: iOS service layer          →  30 min (automated)
Step 3: Replace mock data          →  45 min (automated)
Step 4: HealthKit integration      →  30 min (automated)
Step 5: Authentication flow        →  30 min (automated)
Step 6: Simulator testing          →  30 min (Henry tests)
Step 7: Device testing             →  1 hour (if iPhone available)
Step 8: App Store Connect          →  20 min (you/Henry setup)
Step 9: Archive & upload           →  30 min (Henry does)
Step 10: TestFlight setup          →  15 min (you/Henry does)

TOTAL: ~5 hours (if everything goes smoothly)
REALISTIC: 8-10 hours (with debugging)
```

---

## 🎉 END STATE

**By end of today:**
- Lina'la iOS app fully functional
- Connected to real backend
- Available on TestFlight
- Ready for initial patient testing
- Phase 2 COMPLETE ✅

**Tomorrow:**
- Start Android development (Kotlin)
- Or polish iOS based on TestFlight feedback
- Or fix MyHealthAlly web architecture

---

**Ready to execute?**

**Paste the 3 Cursor prompts and let's finish this. 🚀**
