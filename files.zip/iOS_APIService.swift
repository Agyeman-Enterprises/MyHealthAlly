// APIService.swift
// Lina'la iOS - Backend API Integration

import Foundation

// MARK: - API Configuration

struct APIConfig {
    #if DEBUG
    static let baseURL = "http://localhost:3000"
    #else
    static let baseURL = "https://api.yourdomain.com" // Update when deployed
    #endif
}

// MARK: - API Error

enum APIError: LocalizedError {
    case invalidURL
    case noData
    case decodingError(Error)
    case serverError(Int, String)
    case networkError(Error)
    case unauthorized
    
    var errorDescription: String? {
        switch self {
        case .invalidURL:
            return "Invalid URL"
        case .noData:
            return "No data received from server"
        case .decodingError(let error):
            return "Failed to decode response: \(error.localizedDescription)"
        case .serverError(let code, let message):
            return "Server error (\(code)): \(message)"
        case .networkError(let error):
            return "Network error: \(error.localizedDescription)"
        case .unauthorized:
            return "Session expired. Please login again."
        }
    }
}

// MARK: - API Response Models

struct AuthResponse: Codable {
    let accessToken: String
    let refreshToken: String
    let user: UserProfile
}

struct UserProfile: Codable {
    let id: String
    let email: String
    let role: String
    let clinicId: String?
    let patientId: String?
    let providerId: String?
}

struct PatientResponse: Codable {
    let id: String
    let userId: String
    let clinicId: String
    let firstName: String?
    let lastName: String?
    let dateOfBirth: String?
    let heightCm: Double?
    let flags: [String]
    let createdAt: String
    let updatedAt: String
}

struct PatientAnalytics: Codable {
    let recoveryScore: Double
    let stressLevel: String // low, moderate, high
    let latestVitals: LatestVitals?
    let hrvTrend: [HRVTrendPoint]
    let bmi: BMIReading?
}

struct LatestVitals: Codable {
    let heartRate: Int?
    let spo2: Int?
    let respiration: Int?
    let systolicBP: Int?
    let diastolicBP: Int?
}

struct HRVTrendPoint: Codable {
    let timestamp: String
    let rmssdMs: Double
}

struct BMIReading: Codable {
    let id: String
    let patientId: String
    let timestamp: String
    let weightKg: Double
    let heightCm: Double
    let bmi: Double
}

struct MeasurementResponse: Codable {
    let id: String
    let patientId: String
    let type: String
    let value: MeasurementValue
    let timestamp: String
    let source: String
    let metadata: [String: String]?
    let createdAt: String
}

enum MeasurementValue: Codable {
    case number(Double)
    case object([String: Double])
    
    init(from decoder: Decoder) throws {
        let container = try decoder.singleValueContainer()
        if let number = try? container.decode(Double.self) {
            self = .number(number)
        } else if let object = try? container.decode([String: Double].self) {
            self = .object(object)
        } else {
            throw DecodingError.dataCorrupted(
                DecodingError.Context(
                    codingPath: decoder.codingPath,
                    debugDescription: "Invalid measurement value"
                )
            )
        }
    }
    
    func encode(to encoder: Encoder) throws {
        var container = encoder.singleValueContainer()
        switch self {
        case .number(let value):
            try container.encode(value)
        case .object(let dict):
            try container.encode(dict)
        }
    }
}

struct CarePlanResponse: Codable {
    let id: String
    let patientId: String
    let phases: [CarePlanPhase]
    let createdAt: String
    let updatedAt: String
}

struct CarePlanPhase: Codable {
    let name: String
    let durationWeeks: Int
    let tasks: [CarePlanTask]
}

struct CarePlanTask: Codable {
    let id: String
    let title: String
    let description: String?
    let frequency: String
    let completed: Bool
}

struct AlertResponse: Codable {
    let id: String
    let patientId: String
    let severity: String // INFO, WARNING, CRITICAL
    let type: String
    let title: String
    let body: String
    let status: String // ACTIVE, RESOLVED, DISMISSED
    let createdAt: String
    let resolvedAt: String?
}

struct MessageThreadResponse: Codable {
    let id: String
    let patientId: String
    let clinicId: String?
    let participants: [String]
    let subject: String?
    let lastMessageAt: String?
    let createdAt: String
    let updatedAt: String
    let messages: [MessageResponse]?
}

struct MessageResponse: Codable {
    let id: String
    let threadId: String
    let senderId: String
    let content: String
    let read: Bool
    let readAt: String?
    let createdAt: String
}

// MARK: - API Service

class APIService {
    static let shared = APIService()
    private init() {}
    
    private var accessToken: String? {
        get { UserDefaults.standard.string(forKey: "accessToken") }
        set { UserDefaults.standard.set(newValue, forKey: "accessToken") }
    }
    
    private var refreshToken: String? {
        get { UserDefaults.standard.string(forKey: "refreshToken") }
        set { UserDefaults.standard.set(newValue, forKey: "refreshToken") }
    }
    
    // MARK: - Authentication
    
    func login(email: String, password: String) async throws -> AuthResponse {
        let url = URL(string: "\(APIConfig.baseURL)/auth/login")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String: String] = ["email": email, "password": password]
        request.httpBody = try JSONEncoder().encode(body)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        try validateResponse(response, data: data)
        
        let authResponse = try JSONDecoder().decode(AuthResponse.self, from: data)
        
        // Store tokens
        self.accessToken = authResponse.accessToken
        self.refreshToken = authResponse.refreshToken
        
        return authResponse
    }
    
    func register(email: String, password: String, role: String = "PATIENT") async throws -> AuthResponse {
        let url = URL(string: "\(APIConfig.baseURL)/auth/register")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String: String] = [
            "email": email,
            "password": password,
            "role": role
        ]
        request.httpBody = try JSONEncoder().encode(body)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        try validateResponse(response, data: data)
        
        let authResponse = try JSONDecoder().decode(AuthResponse.self, from: data)
        
        // Store tokens
        self.accessToken = authResponse.accessToken
        self.refreshToken = authResponse.refreshToken
        
        return authResponse
    }
    
    func logout() {
        self.accessToken = nil
        self.refreshToken = nil
    }
    
    // MARK: - Patient Endpoints
    
    func getPatientProfile() async throws -> PatientResponse {
        let url = URL(string: "\(APIConfig.baseURL)/patients/me")!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("Bearer \(accessToken ?? "")", forHTTPHeaderField: "Authorization")
        
        let (data, response) = try await URLSession.shared.data(for: request)
        try validateResponse(response, data: data)
        
        return try JSONDecoder().decode(PatientResponse.self, from: data)
    }
    
    func getPatientAnalytics() async throws -> PatientAnalytics {
        let url = URL(string: "\(APIConfig.baseURL)/patients/analytics")!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("Bearer \(accessToken ?? "")", forHTTPHeaderField: "Authorization")
        
        let (data, response) = try await URLSession.shared.data(for: request)
        try validateResponse(response, data: data)
        
        let decoder = JSONDecoder()
        decoder.keyDecodingStrategy = .convertFromSnakeCase
        return try decoder.decode(PatientAnalytics.self, from: data)
    }
    
    func getMeasurements(patientId: String) async throws -> [MeasurementResponse] {
        let url = URL(string: "\(APIConfig.baseURL)/patients/\(patientId)/measurements")!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("Bearer \(accessToken ?? "")", forHTTPHeaderField: "Authorization")
        
        let (data, response) = try await URLSession.shared.data(for: request)
        try validateResponse(response, data: data)
        
        return try JSONDecoder().decode([MeasurementResponse].self, from: data)
    }
    
    func logMeasurement(
        patientId: String,
        type: String,
        value: MeasurementValue,
        timestamp: Date,
        source: String = "MANUAL"
    ) async throws -> MeasurementResponse {
        let url = URL(string: "\(APIConfig.baseURL)/patients/\(patientId)/measurements")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(accessToken ?? "")", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let iso8601Formatter = ISO8601DateFormatter()
        let timestampString = iso8601Formatter.string(from: timestamp)
        
        let body: [String: Any] = [
            "type": type,
            "value": value,
            "timestamp": timestampString,
            "source": source
        ]
        
        request.httpBody = try JSONSerialization.data(withJSONObject: body)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        try validateResponse(response, data: data)
        
        return try JSONDecoder().decode(MeasurementResponse.self, from: data)
    }
    
    func getCarePlan(patientId: String) async throws -> CarePlanResponse {
        let url = URL(string: "\(APIConfig.baseURL)/patients/\(patientId)/care-plans")!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("Bearer \(accessToken ?? "")", forHTTPHeaderField: "Authorization")
        
        let (data, response) = try await URLSession.shared.data(for: request)
        try validateResponse(response, data: data)
        
        return try JSONDecoder().decode(CarePlanResponse.self, from: data)
    }
    
    // MARK: - Alerts
    
    func getAlerts() async throws -> [AlertResponse] {
        let url = URL(string: "\(APIConfig.baseURL)/alerts")!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("Bearer \(accessToken ?? "")", forHTTPHeaderField: "Authorization")
        
        let (data, response) = try await URLSession.shared.data(for: request)
        try validateResponse(response, data: data)
        
        return try JSONDecoder().decode([AlertResponse].self, from: data)
    }
    
    // MARK: - Messaging
    
    func getMessageThreads() async throws -> [MessageThreadResponse] {
        let url = URL(string: "\(APIConfig.baseURL)/messaging/threads")!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("Bearer \(accessToken ?? "")", forHTTPHeaderField: "Authorization")
        
        let (data, response) = try await URLSession.shared.data(for: request)
        try validateResponse(response, data: data)
        
        return try JSONDecoder().decode([MessageThreadResponse].self, from: data)
    }
    
    func getThread(threadId: String) async throws -> MessageThreadResponse {
        let url = URL(string: "\(APIConfig.baseURL)/messaging/threads/\(threadId)")!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        request.setValue("Bearer \(accessToken ?? "")", forHTTPHeaderField: "Authorization")
        
        let (data, response) = try await URLSession.shared.data(for: request)
        try validateResponse(response, data: data)
        
        return try JSONDecoder().decode(MessageThreadResponse.self, from: data)
    }
    
    func sendMessage(threadId: String, content: String) async throws -> MessageResponse {
        let url = URL(string: "\(APIConfig.baseURL)/messaging/threads/\(threadId)/messages")!
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("Bearer \(accessToken ?? "")", forHTTPHeaderField: "Authorization")
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        
        let body: [String: String] = ["content": content]
        request.httpBody = try JSONEncoder().encode(body)
        
        let (data, response) = try await URLSession.shared.data(for: request)
        try validateResponse(response, data: data)
        
        return try JSONDecoder().decode(MessageResponse.self, from: data)
    }
    
    // MARK: - Helper Methods
    
    private func validateResponse(_ response: URLResponse, data: Data) throws {
        guard let httpResponse = response as? HTTPURLResponse else {
            throw APIError.networkError(NSError(domain: "Invalid response", code: -1))
        }
        
        switch httpResponse.statusCode {
        case 200...299:
            return
        case 401:
            // Token expired - logout
            logout()
            throw APIError.unauthorized
        case 400...499:
            let errorMessage = String(data: data, encoding: .utf8) ?? "Client error"
            throw APIError.serverError(httpResponse.statusCode, errorMessage)
        case 500...599:
            let errorMessage = String(data: data, encoding: .utf8) ?? "Server error"
            throw APIError.serverError(httpResponse.statusCode, errorMessage)
        default:
            throw APIError.serverError(httpResponse.statusCode, "Unknown error")
        }
    }
}
