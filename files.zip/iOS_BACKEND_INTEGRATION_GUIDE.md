# 🚀 LINA'LA iOS - BACKEND INTEGRATION GUIDE

**For: Henry (Developer/MA/Practice Manager)**  
**Date:** November 23, 2025  
**Status:** Ready to Implement

---

## 📋 OVERVIEW

This guide will walk you through integrating the Lina'la iOS app with the MyHealthAlly NestJS backend. All code has been prepared - you just need to add files to Xcode and update existing views.

**Time Required:** 1-2 hours

---

## ✅ PREREQUISITES

- [x] Xcode installed on Mac
- [x] Lina'la iOS project open
- [x] MyHealthAlly backend running on `http://localhost:3000`
- [x] Backend health check responding: `http://localhost:3000/health`

**Verify backend is running:**
```bash
curl http://localhost:3000/health
# Should return: {"status":"ok","timestamp":"..."}
```

---

## 📁 FILES TO ADD

You've been provided with 3 new Swift files:

1. **iOS_APIService.swift** - Complete backend API client
2. **iOS_AuthenticationManager_Updated.swift** - Real authentication
3. **iOS_ViewModels_Updated.swift** - Real data ViewModels

---

## 🔧 STEP-BY-STEP INTEGRATION

### Step 1: Add APIService.swift to Xcode (10 min)

1. **Open** Xcode project: `~/Desktop/linala/apps/ios/Linala/Linala.xcodeproj`

2. **Right-click** on the `Services` folder in Xcode sidebar

3. **Select** "Add Files to 'Linala'..."

4. **Navigate** to where you saved `iOS_APIService.swift`

5. **Settings** when adding:
   - ☑️ Copy items if needed (CHECK THIS!)
   - ☑️ Add to targets: Linala (CHECK THIS!)
   - Click "Add"

6. **Delete** the old `SupabaseService.swift` file (we're not using Supabase in Phase 2)
   - Right-click → Delete → Move to Trash

---

### Step 2: Replace AuthenticationManager (5 min)

1. **Find** `AuthenticationManager.swift` in the `Managers` folder

2. **Click** the file to open it

3. **Select All** (⌘+A) and **Delete**

4. **Open** `iOS_AuthenticationManager_Updated.swift` in a text editor

5. **Copy** all content (⌘+C)

6. **Paste** into the empty `AuthenticationManager.swift` in Xcode (⌘+V)

7. **Save** (⌘+S)

---

### Step 3: Add Updated ViewModels (10 min)

1. **Open** `iOS_ViewModels_Updated.swift` in a text editor

2. **Copy** all content

3. **In Xcode**, find these files:
   - `ViewModels/HomeViewModel.swift`
   - `ViewModels/VitalsViewModel.swift`
   - `ViewModels/MessagesViewModel.swift`
   - (Create `ViewModels/ProfileViewModel.swift` if it doesn't exist)

4. **For each ViewModel file**:
   - Select all content (⌘+A)
   - Paste new content (⌘+V)
   - Save (⌘+S)

**Or create a new file:**
- Right-click `ViewModels` folder
- New File → Swift File
- Name: `AllViewModels.swift`
- Paste entire `iOS_ViewModels_Updated.swift` content
- This creates all ViewModels in one file (simpler)

---

### Step 4: Update View Files to Use New ViewModels (15 min)

#### 4.1 Update SignInView.swift

**Find this code:**
```swift
Button("Sign In") {
    // Mock login
    authManager.isAuthenticated = true
}
```

**Replace with:**
```swift
Button("Sign In") {
    Task {
        await authManager.login(email: email, password: password)
    }
}
.disabled(authManager.isLoading)

// Add loading indicator
if authManager.isLoading {
    ProgressView()
}

// Add error message
if let error = authManager.errorMessage {
    Text(error)
        .foregroundColor(.red)
        .font(.caption)
}
```

#### 4.2 Update SignUpView.swift

**Find this code:**
```swift
Button("Create Account") {
    // Mock registration
    authManager.isAuthenticated = true
}
```

**Replace with:**
```swift
Button("Create Account") {
    Task {
        await authManager.register(email: email, password: password)
    }
}
.disabled(authManager.isLoading)

if authManager.isLoading {
    ProgressView()
}

if let error = authManager.errorMessage {
    Text(error)
        .foregroundColor(.red)
        .font(.caption)
}
```

#### 4.3 Update HomeView.swift

**Add at the top:**
```swift
@StateObject private var viewModel = HomeViewModel()
```

**Add in the body:**
```swift
.onAppear {
    Task {
        await viewModel.loadDashboardData()
    }
}
```

**Update to use real data:**
```swift
// Instead of hardcoded "Welcome, Sarah"
Text("Welcome, \(viewModel.displayName)")

// Use real vitals
if let hr = viewModel.currentHeartRate {
    VitalCard(title: "Heart Rate", value: "\(hr) bpm")
}

if let bp = viewModel.currentBloodPressure {
    VitalCard(title: "Blood Pressure", value: bp)
}
```

#### 4.4 Update VitalsListView.swift

**Add at the top:**
```swift
@StateObject private var viewModel = VitalsViewModel()
```

**Add in the body:**
```swift
.onAppear {
    // Get patientId from AuthenticationManager
    if let patientId = authManager.currentUser?.patientId {
        viewModel.setPatientId(patientId)
        Task {
            await viewModel.loadVitals()
        }
    }
}
```

**Display real vitals:**
```swift
List(viewModel.measurements) { measurement in
    VitalRow(measurement: measurement)
}
```

#### 4.5 Update MessagesView.swift

**Add at the top:**
```swift
@StateObject private var viewModel = MessagesViewModel()
```

**Add in the body:**
```swift
.onAppear {
    Task {
        await viewModel.loadThreads()
    }
}
```

**Display real threads:**
```swift
List(viewModel.threads) { thread in
    NavigationLink(destination: ThreadDetailView(threadId: thread.id)) {
        MessageThreadRow(thread: thread)
    }
}
```

---

### Step 5: Build and Test in Simulator (15 min)

1. **Select Simulator**: iPhone 15 Pro

2. **Build** (⌘+B)
   - Should compile with no errors
   - If errors, check imports and file names

3. **Run** (⌘+R)
   - App launches in Simulator

4. **Test Registration:**
   - Tap "Create Account"
   - Email: `test@example.com`
   - Password: `password123`
   - Tap "Create Account" button
   - Should show loading spinner
   - Should navigate to HomeView after success

5. **Test Login:**
   - Logout
   - Tap "Sign In"
   - Use same credentials
   - Should authenticate and show HomeView

6. **Test Dashboard:**
   - HomeView should load real patient data
   - Vitals should display (if any data in backend)
   - If no data yet, they'll be empty (that's OK)

7. **Test Vitals Logging:**
   - Navigate to Vitals screen
   - Tap "Log New Vital"
   - Enter blood pressure: 120/80
   - Save
   - Should appear in list immediately

---

## 🧪 TESTING CHECKLIST

### Authentication ✅
- [ ] Create new account works
- [ ] Login with existing account works
- [ ] Wrong password shows error message
- [ ] Empty fields show validation error
- [ ] Logout works
- [ ] Token persists after app restart

### Dashboard ✅
- [ ] Loads patient name
- [ ] Shows recovery score (if available)
- [ ] Shows latest vitals (if available)
- [ ] Loading spinner shows while fetching
- [ ] Error message shows if backend unavailable

### Vitals ✅
- [ ] List loads existing vitals
- [ ] Can log new blood pressure
- [ ] Can log new glucose reading
- [ ] Can log new weight
- [ ] New vitals appear immediately
- [ ] Shows empty state if no vitals

### Messages ✅
- [ ] List loads message threads
- [ ] Can open a thread
- [ ] Can send a new message
- [ ] Messages appear in thread
- [ ] Shows empty state if no threads

### Profile ✅
- [ ] Shows patient information
- [ ] Shows clinic name
- [ ] Can edit profile (future)
- [ ] Logout works

---

## 🔍 TROUBLESHOOTING

### Error: "Cannot connect to backend"

**Solution:**
```bash
# Verify backend is running
curl http://localhost:3000/health

# If not running, start it
cd ~/path/to/myhealthally/packages/backend
pnpm dev
```

### Error: "Invalid URL"

**Check:** `APIService.swift` line 14:
```swift
static let baseURL = "http://localhost:3000"
```

Make sure there's no trailing slash.

### Error: "401 Unauthorized"

**Cause:** Access token expired (after 15 minutes)

**Solution:** Logout and login again. Token refresh will be added in Phase 3.

### Build Errors

**Common issues:**
1. File not added to target → Re-add with "Add to targets" checked
2. Duplicate file names → Delete old mock files first
3. Import errors → Make sure all files are in correct folders

---

## 📱 DEVICE TESTING (Optional - If iPhone Available)

### For Physical iPhone:

1. **Find your Mac's local IP:**
   ```bash
   ifconfig | grep "inet " | grep -v 127.0.0.1
   # Example output: inet 192.168.1.100
   ```

2. **Update APIService.swift:**
   ```swift
   #if DEBUG
   static let baseURL = "http://192.168.1.100:3000"  // Your Mac's IP
   #else
   static let baseURL = "https://api.yourdomain.com"
   #endif
   ```

3. **Ensure Mac firewall allows port 3000:**
   - System Settings → Network → Firewall
   - Allow incoming connections on port 3000

4. **Connect iPhone via cable**

5. **Select iPhone as build target** in Xcode

6. **Build and Run** (⌘+R)

7. **Test same features** as Simulator

---

## 🎯 SUCCESS CRITERIA

**Phase 2 Backend Integration is complete when:**

1. ✅ User can register and login with real credentials
2. ✅ Dashboard loads real patient data
3. ✅ Vitals can be logged and retrieved
4. ✅ Messages can be sent and received
5. ✅ Profile shows real patient information
6. ✅ No mock data in the app
7. ✅ All API calls go to NestJS backend
8. ✅ Errors are handled gracefully
9. ✅ Loading states show during API calls
10. ✅ App works on both Simulator and Device

---

## 📸 SCREENSHOTS TO TAKE

After testing, take screenshots of:

1. Login screen with real credentials
2. Home dashboard with real data
3. Vitals list showing measurements
4. Vital logging screen (before and after)
5. Messages screen with threads
6. Profile screen with patient info

Send screenshots to confirm everything works!

---

## 🚀 NEXT STEPS (Phase 3)

After Phase 2 is working:

1. **HealthKit Integration** - Auto-sync vitals from Apple Health
2. **Push Notifications** - Real-time alerts
3. **Token Refresh** - Automatic token renewal
4. **Offline Support** - Cache data locally
5. **TestFlight Deployment** - Beta testing

---

## 📞 REPORTING

**After completion, send me:**

1. ✅ "Phase 2 integration complete"
2. 📸 Screenshots of working app
3. 🐛 Any issues encountered
4. ⏱️ Time taken

**If stuck:**
- Share the error message
- Share the line of code causing the error
- Share screenshot of the error in Xcode

---

## 🎉 YOU GOT THIS!

This integration is straightforward - all the code is written, you're just connecting the pieces. Take your time, follow each step, and test as you go.

**Estimated completion time:** 1-2 hours

**Let's finish Phase 2! 🚀**
