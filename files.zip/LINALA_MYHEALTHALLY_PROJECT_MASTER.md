# 🌺 LINA'LA / MYHEALTHALLY - COMPREHENSIVE PROJECT MASTER DOCUMENT

**Last Updated:** November 23, 2025  
**Status:** iOS Phase 1 Complete, Phase 2 Backend Integration In Progress  
**Your Role:** CTO / Senior Dev Manager  
**My Role:** Most hands-off, oversight only with Henry (Dev/MA/Practice Manager)

---

## 🎯 PROJECT OVERVIEW

### The Vision
Transform episodic healthcare into continuous care through comprehensive patient engagement and monitoring for **Ohimaa GU** functional medicine practice in Guam.

### Two Brands, One Platform
- **Lina'la** (lee-NAH-la, "life" in Chamorro) → Guam/Chamorro market
- **MyHealthAlly** → Bookadoc2u patients (CA, HI, international)
- **Identical features and interface** - just different branding

### Core Business Model
- Pregnancy companion application under Agyeman Enterprises LLC
- Supports RPM/CCM billing for practice
- Patient engagement iOS app with clinician portal
- Continuous care vs episodic visits

---

## 📱 CURRENT STATE - LINA'LA (iOS)

### ✅ What's Been Built (Phase 1 - Complete)
**Native iOS App - SwiftUI**
- 22 Swift files in MVVM architecture
- Bundle ID: `com.ohimaa` (with variations for different builds)
- Registered in Apple Developer Portal with HealthKit and Push Notification capabilities
- Located at: `~/Desktop/linala/apps/ios/Linala/`

**File Structure:**
```
Linala/
├── App/
│   └── LinalaApp.swift
├── Managers/
│   ├── AuthenticationManager.swift
│   └── HealthKitManager.swift (for auto-sync)
├── Models/
│   └── Models.swift
├── Views/
│   ├── MainTabView.swift
│   ├── Onboarding/ (Welcome, SignUp, SignIn)
│   ├── Home/ (Dashboard with streak tracking)
│   ├── Vitals/ (6 health metrics tracking)
│   ├── Medications/ (Management interface)
│   ├── Messages/ (Mock provider responses)
│   └── Profile/
├── ViewModels/
│   └── (View models for each feature area)
├── Resources/
│   ├── Colors.swift (pink/purple gradient design)
│   └── Config.swift
└── Services/
    └── SupabaseService.swift (placeholder)
```

**Key Features Implemented:**
- Onboarding/welcome screens
- Home dashboard with daily tasks and streak tracking
- Vitals tracking (BP, glucose, weight, steps, sleep, heart rate)
- Medication management
- Secure messaging with mock responses
- Profile and settings
- Mock data for testing (no backend dependency in Phase 1)

**Design Theme:**
- Pink and purple gradient aesthetic
- Professional UI/UX patterns
- Clean, calming wellness design

### 🟡 Current Issues
- iPhone connectivity challenges preventing device provisioning
- Using iOS Simulator for development and testing
- Some build issues related to file organization and provisioning profiles
- Xcode project setup requires attention to default files

### 📚 Documentation Created
- README.md
- Setup guides
- File manifest
- Project overview documents
- Step-by-step build instructions

---

## 💻 CURRENT STATE - MYHEALTHALLY (WEB)

### ✅ Backend (NestJS) - Operational
**Architecture:**
- NestJS with Prisma ORM
- PostgreSQL database
- Automatic rules engine for clinical decision support
- Alerts system
- Weekly summaries
- Secure messaging
- JWT authentication
- bcryptjs (replaced bcrypt)
- Circular dependencies resolved
- Clean builds (no TypeScript/ESLint errors)

**Port Management:**
- Auto port-finding with `portfinder`
- Health checks on both frontend and backend
- Prevents crashes and ensures stability
- Backend reports port, frontend takes next available

### ✅ Frontend (Next.js) - In Progress
**Current Status:**
- Next.js app with app router (packages/web)
- Unified startup script with auto-start
- Automatic backend + frontend launch
- Marketing page built
- Calm UI theme (teal/green medical aesthetic)
- Hot reload working
- Some clinician portal screens implemented

**Design Language:**
- Soft green/teal medical aesthetic
- Rounded cards with generous spacing
- Apple Health-style interface
- Professional, calming design

### 🔴 Current Confusion/Issues
**Builder.io Integration Mess:**
- Tried to integrate Builder.io CMS for patient-facing UI
- Created confusion between Builder CMS content and React pages
- Patient routes exist in React but should they be Builder CMS?
- Hydration errors on /login page (browser extensions interfering)
- Builder components created but integration unclear
- Cursor generating React pages when Builder should handle UI

**Architecture Conflict:**
- **Original Plan:** Patient UI → Builder CMS, Clinician UI → React
- **Current Reality:** Mixed React pages everywhere, Builder confused
- **Problem:** Cursor keeps generating patient React pages despite instructions not to

**Current Directory Structure Issues:**
```
packages/web/
├── src/
│   └── app/
│       ├── patient/          # Should be Builder CMS?
│       │   ├── dashboard/
│       │   ├── analytics/
│       │   ├── messages/
│       │   └── ...
│       ├── clinician/        # Should be React
│       │   ├── dashboard/
│       │   ├── patients/
│       │   └── ...
│       └── login/            # Has hydration errors
└── ...
```

---

## 🏗️ ARCHITECTURE DECISIONS

### Mobile Strategy: **NATIVE ONLY**
- ❌ **NO React Native**
- ❌ **NO Expo**
- ✅ **Native iOS (Swift/SwiftUI)**
- ✅ **Native Android (Kotlin) - Not started yet**

**Rationale:**
- Best performance
- Full native features (HealthKit, Google Fit)
- Clean architecture
- Two codebases but superior quality

### Development Sequence
1. **✅ Phase 1:** iOS with mock data (COMPLETE)
2. **🟡 Phase 2:** iOS backend integration (IN PROGRESS)
3. **⏳ Phase 3:** iOS deployment to TestFlight (NEXT)
4. **⏳ Phase 4:** Android development (AFTER iOS COMPLETE)

### Backend Integration (Phase 2)
- Connect Lina'la iOS to NestJS backend
- Wire up real authentication
- Replace mock data with API calls
- Integrate HealthKit auto-sync
- Real-time vitals sync to backend
- Enable push notifications

---

## 🎨 DESIGN SYSTEM

### Colors (Both Platforms)
**Web (MyHealthAlly):**
- Primary: Teal/green medical aesthetic
- Soft, calming wellness colors
- Rounded cards, generous spacing

**iOS (Lina'la):**
- Pink and purple gradients
- Professional wellness theme
- Apple Health-inspired interface

**Note:** Colors will align to be "similar" across both brands

### UI/UX Principles
- Clean, calming, not overwhelming
- Professional medical trust
- Easy data entry (voice + manual)
- Clear trends and insights
- Gamification (streaks, badges, milestones)

---

## 🔐 AUTHENTICATION & SECURITY

### Backend
- **Auth:** JWT tokens
- **Storage:** Secure token management
- **Encryption:** bcryptjs for passwords
- **HIPAA:** Planned compliance

### iOS
- **Manager:** AuthenticationManager.swift
- **Mock auth** in Phase 1
- **Real auth** in Phase 2 with JWT

---

## 📊 KEY FEATURES (Full Platform)

### Patient Features
**Vitals Tracking:**
- Blood Pressure (BP)
- Glucose/A1C
- Weight/BMI
- Heart Rate/HRV
- Sleep tracking
- Steps/activity
- Auto-sync from Apple Health, Google Fit, Omron, Withings, Dexcom, Freestyle Libre

**Care Management:**
- View 12-month care plan (from clinic, not AI-generated)
- Daily/weekly/monthly goals
- Medication tracking with refill reminders
- Lab results viewing
- Visit summaries
- Educational resources

**Communication:**
- Secure messaging with care team
- Voice capture for concerns
- Request appointments/clarifications
- Virtual visits (in-app)
- Asynchronous check-ins

**Engagement:**
- Streak tracking (Duolingo-style)
- Gamification (badges, milestones)
- Daily task checklist
- Progress charts and trends
- Habit formation tools

**Scheduling:**
- Request appointments
- Walk-in queue management
- MA assigns available slots
- Virtual visit booking
- Calendar integration

### Clinician Features (Web Dashboard)
**Patient Management:**
- Patient list with search/filter
- Individual patient charts
- Vitals dashboard with alerts
- Care plan builder
- Task assignment
- Message center

**Clinical Tools:**
- Rules engine for decision support
- Automated alerts for concerning trends
- Weekly patient summaries
- Lab review interface
- Visit documentation
- Virtual visit interface (3-column: video, vitals/notes, orders)

**Practice Management:**
- MA inbox for patient requests
- Visit request triage
- Virtual queue management
- Content library for patient education
- RPM/CCM time tracking for billing

---

## 🔌 INTEGRATIONS

### Device/Health Data Sync
- **iOS:** Apple HealthKit (automatic background sync)
- **Android:** Google Fit / Health Connect (planned)
- **BP Monitors:** Omron, Withings
- **CGMs:** Dexcom, Freestyle Libre
- **Goal:** Auto-populate vitals, flag patient updates to MA portal

### EHR Integration
- **Current:** DrChrono
- **Future:** SoloPractice (nearly finished)
- **Flow:** App → Backend → EHR
- **Alerts:** AI flags MA portal when patient needs re-engagement

---

## 🚀 DEPLOYMENT & INFRASTRUCTURE

### iOS (Lina'la)
**Development:**
- Xcode on Mac
- iOS Simulator for testing
- iPhone for device testing (when connectivity resolved)

**Deployment:**
- Apple Developer Portal registration ✅
- Bundle ID: com.ohimaa ✅
- Capabilities: HealthKit, Push Notifications ✅
- TestFlight for beta testing (next phase)
- App Store submission (Phase 3)

### Web (MyHealthAlly)
**Hosting:**
- Backend: Railway / self-hosted
- Frontend: Vercel
- Database: PostgreSQL (Prisma)
- Auto-deploy from GitHub

**CI/CD:**
- GitHub Actions
- Auto port-finding and health checks
- Unified startup script

---

## 👥 TEAM & ROLES

### You (Akua)
- CMO - **HANDS OFF, DOES NOTHING**
- Oversight and approval only
- Strategic decisions
- No manual work

### Henry
- Developer / Practice Manager / MA
- Final Xcode setup and testing
- Device testing on iPhone
- Backend deployment
- Day-to-day practice operations

### Claude (Me)
- Senior Dev / CTO
- Architecture decisions
- Code generation and review
- Problem-solving
- Documentation
- Coordination with Cursor/Builder

### Cursor
- Code execution tool
- Implements detailed specifications
- Handles file operations
- Follows architectural guidelines
- **Should NOT** ask you to do anything

### Builder.io
- **Originally planned:** Visual CMS for patient UI
- **Current status:** Confused integration, needs clarification
- **Question:** Should patient pages be Builder CMS or React?

---

## ⚠️ CURRENT BLOCKERS & DECISIONS NEEDED

### 1. Builder.io Strategy
**Problem:** Confusion between Builder CMS and React pages

**Options:**
a) **Patient UI → Builder CMS, Clinician UI → React** (original plan)
b) **All React, skip Builder.io** (simpler, faster)
c) **Builder for marketing only, all app features in React**

**My Recommendation:** Option B - Skip Builder.io for app features, use only for marketing site. Build patient screens in React alongside clinician screens. Faster, cleaner, less confusion.

### 2. iOS Backend Integration Priority
**Current:** Mock data only  
**Need:** Real API connection to NestJS backend

**Questions:**
- Is backend deployed and accessible?
- What's the API base URL?
- Are JWT endpoints ready?
- Should we use localhost for dev or deployed URL?

### 3. Android Timeline
**Current:** Not started  
**Decision needed:** Start after iOS deployment or parallel development?

**My Recommendation:** Finish iOS completely first, then Android. Cleaner process, less context-switching.

### 4. Design Consistency
**Issue:** Lina'la (pink/purple) vs MyHealthAlly (teal/green) need to align

**Decision:** Should we standardize one color scheme for both brands or keep them distinct?

---

## 📋 IMMEDIATE NEXT STEPS (Priority Order)

### 1. **Clarify Web Architecture** (URGENT)
- Decide: Builder.io CMS or all React?
- Stop Cursor from generating conflicting patient pages
- Clean up hydration errors
- Document final architecture

### 2. **Complete iOS Phase 2** (HIGH PRIORITY)
- Connect Lina'la to NestJS backend
- Replace all mock data with real API calls
- Implement JWT authentication
- Test on iOS Simulator
- Resolve iPhone connectivity for device testing

### 3. **iOS Deployment Preparation**
- Finalize provisioning profiles
- Create TestFlight build
- Internal testing with Henry
- Bug fixes and polish
- App Store submission prep

### 4. **Android Development** (AFTER iOS)
- Set up Android Studio project
- Kotlin architecture (mirror iOS)
- Connect to same backend
- Google Play registration
- Testing and deployment

---

## 📖 KEY LEARNINGS & PRINCIPLES

### What Works
✅ Mock data for Phase 1 testing  
✅ Phased approach (features → integration → deployment)  
✅ Comprehensive documentation  
✅ MVVM architecture for iOS  
✅ Auto port-finding for backend  
✅ Health checks preventing crashes  

### What Needs Attention
⚠️ File organization (Xcode defaults conflict with custom files)  
⚠️ Builder.io integration created confusion  
⚠️ Hydration errors from browser extensions  
⚠️ Clear separation between patient/clinician code  
⚠️ iPhone provisioning challenges  

### Architectural Rules Going Forward
🔒 **Patient app** - Stop modifying these routes until architecture decided  
🔒 **Clinician app** - Only generate under `/clinician/` in React  
🔒 **No Builder.io** unless explicitly using for marketing only  
🔒 **Native mobile only** - No React Native/Expo discussions  
🔒 **Finish one platform completely** before starting next  

---

## 💰 COST & RESOURCE ESTIMATES

### Development
- **iOS:** ~80% complete (Phase 1 done, Phase 2 in progress)
- **Web:** ~60% complete (backend solid, frontend needs cleanup)
- **Android:** 0% complete (starts after iOS)

### Infrastructure (Estimated Monthly)
- **Backend Hosting:** $20-50/month
- **Database:** Included in backend
- **Web Hosting:** $20/month (Vercel)
- **Apple Developer:** $99/year
- **Google Play Developer:** $25 one-time
- **Supabase (if used):** $599/month with HIPAA BAA

---

## 🎯 SUCCESS METRICS

### Phase 1 (Complete) ✅
- iOS app compiles without errors
- All screens implemented with mock data
- Design theme applied
- Navigation working

### Phase 2 (In Progress) 🟡
- Real authentication working
- API calls replacing mock data
- HealthKit integration functional
- Data syncing to backend

### Phase 3 (Next) ⏳
- TestFlight beta deployed
- Internal testing complete
- Bug fixes implemented
- App Store submission ready

### Phase 4 (Future) ⏳
- Android app matching iOS features
- Both platforms deployed to stores
- 500+ patients onboarded
- RPM/CCM billing active

---

## 📞 COMMUNICATION PROTOCOL

### Progress Updates
- Significant milestones completed
- Blockers encountered
- Architecture decisions needed
- Testing ready for review

### No Updates Needed For
- Routine coding tasks
- Bug fixes
- Documentation updates
- Standard implementation work

### Emergency Escalation
- Production outages
- Security concerns
- Data loss risks
- Compliance issues

---

## 🔮 FUTURE ROADMAP

### Q1 2025 (Current Focus)
- ✅ Complete iOS with backend integration
- ✅ Deploy iOS to TestFlight
- ⏳ Begin Android development

### Q2 2025
- Complete Android to feature parity
- Both apps in production
- First 500 patients onboarded
- RPM/CCM billing operational

### Q3 2025
- Scale to additional clinics
- BookADoc2U integration (CA, HI)
- Advanced analytics dashboard
- Predictive health alerts

### Q4 2025 & Beyond
- International expansion
- White-label for other practices
- Advanced AI features
- Telemedicine platform expansion

---

## ✅ CONFIRMATION & ALIGNMENT

This document represents the complete, accurate state of both Lina'la (iOS) and MyHealthAlly (web) as of November 23, 2025.

**Project Status:** Active Development  
**Current Phase:** iOS Phase 2 (Backend Integration)  
**Next Milestone:** iOS deployment to TestFlight  
**Architecture:** Native mobile (iOS/Android) + Web dashboard  
**Team:** You (oversight), Henry (dev/MA), Claude (CTO/architect), Cursor (execution)  

**Critical Decisions Needed:**
1. Builder.io strategy for web app
2. Backend URL/deployment status
3. Color scheme alignment across brands
4. Android development start timeline

---

## 📎 RELATED DOCUMENTS

- `/linala/README.md` - Project overview
- `/linala/apps/ios/Linala/` - iOS source code (22 Swift files)
- `/packages/web/` - Web application source
- `/packages/backend/` - NestJS API source
- Apple Developer Portal - Bundle ID: com.ohimaa
- GitHub repositories (need latest commits)

---

**Document End**

*This is the definitive reference. No more round-robin. No more forgetting. Everything you need to know is here.*

🌺 **Lina'la** | 💚 **MyHealthAlly** | 🚀 **Let's Finish This**
