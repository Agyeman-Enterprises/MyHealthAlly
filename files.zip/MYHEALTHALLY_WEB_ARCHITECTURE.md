# 🌐 MYHEALTHALLY WEB - ARCHITECTURE CLARIFICATION

**For: Cursor AI (Code Executor)**  
**From: Claude (Senior Dev/CTO)**  
**Date:** November 23, 2025  

---

## 🚨 IMMEDIATE DIRECTIVE: STOP ALL PATIENT PAGE GENERATION

**CRITICAL:** Do not generate, modify, or touch any files under:
- `/src/app/patient/`
- `/src/app/login/`
- `/src/components/patient/`
- `/src/services/patient/`

**Why:** We are resolving Builder.io integration confusion first.

---

## 📋 CURRENT STATE ASSESSMENT

### What's Working ✅
- NestJS backend with Prisma
- JWT authentication
- Auto port-finding with health checks
- Database schema complete
- Clean builds (no TS errors)
- Backend API endpoints functional

### What's Broken 🔴
- **Builder.io Integration Confusion**
  - Patient React pages exist but should they be CMS?
  - Builder components created but not properly integrated
  - Hydration errors on /login page
  - Unclear ownership: Builder vs React

- **File Organization Issues**
  - Builder components in `/src/components/builder/`
  - Patient components in `/src/components/patient/`
  - Duplicate/conflicting code paths

- **Hydration Errors**
  - `/login` page has hydration mismatch
  - Browser extensions (LastPass, Grammarly) interfering
  - Need `suppressHydrationWarning` flags

---

## 🎯 DECISION: SIMPLIFIED ARCHITECTURE

### New Architecture (Effective Immediately)

```
MyHealthAlly Web = Single Next.js App

Frontend Structure:
├── Public Marketing Site (/)
│   ├── Landing page
│   ├── Features
│   ├── Pricing
│   └── About
│
├── Patient Portal (/patient)
│   ├── All screens in React (NOT Builder CMS)
│   ├── Dashboard, Analytics, Messages, etc.
│   └── Built with shadcn/ui components
│
└── Clinician Portal (/clinician)
    ├── All screens in React
    ├── Dashboard, Patient List, Virtual Visits
    └── Built with shadcn/ui components
```

### What This Means

**✅ DO:**
- Build everything in React/Next.js
- Use shadcn/ui for consistent components
- Follow the design system (teal/green medical aesthetic)
- Keep patient and clinician code separate

**❌ DON'T:**
- Use Builder.io for app features
- Create Builder CMS models
- Mix CMS content with React pages
- Try to integrate BuilderPage components

**💡 OPTIONAL (Later):**
- Use Builder.io for marketing site ONLY (not app features)
- This avoids all confusion and speeds up development

---

## 📐 FILE STRUCTURE (Correct)

```
packages/web/
├── src/
│   ├── app/
│   │   ├── (marketing)/          # Public site
│   │   │   ├── page.tsx           # Landing
│   │   │   ├── features/
│   │   │   ├── pricing/
│   │   │   └── about/
│   │   │
│   │   ├── login/                 # Shared login
│   │   │   └── page.tsx
│   │   │
│   │   ├── patient/               # Patient portal
│   │   │   ├── layout.tsx         # Patient wrapper
│   │   │   ├── dashboard/
│   │   │   ├── analytics/
│   │   │   ├── messages/
│   │   │   ├── schedule/
│   │   │   └── profile/
│   │   │
│   │   └── clinician/             # Clinician portal
│   │       ├── layout.tsx         # Clinician wrapper
│   │       ├── dashboard/
│   │       ├── patients/
│   │       ├── patients/[id]/
│   │       ├── visit/[id]/
│   │       ├── tasks/
│   │       └── messages/
│   │
│   ├── components/
│   │   ├── ui/                    # shadcn components
│   │   ├── patient/               # Patient-specific
│   │   ├── clinician/             # Clinician-specific
│   │   └── shared/                # Reusable across both
│   │
│   ├── lib/
│   │   ├── api/                   # API client
│   │   ├── auth/                  # Auth utilities
│   │   └── utils.ts
│   │
│   └── styles/
│       └── globals.css
│
├── public/
│   ├── images/
│   └── icons/
│
└── [config files]
```

---

## 🛠️ IMPLEMENTATION STEPS

### Step 1: Clean Up Builder.io Code

**Remove these directories:**
```bash
rm -rf src/components/builder/
rm -rf src/services/builder/
```

**Remove from package.json:**
```json
// Delete this line:
"@builder.io/react": "^8.2.9"
```

**Run:**
```bash
pnpm remove @builder.io/react
```

---

### Step 2: Fix Login Page Hydration Error

**File:** `src/app/login/page.tsx`

**Add to RootLayout:** `src/app/layout.tsx`
```tsx
export default function RootLayout({ children }: { children: React.Node }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body suppressHydrationWarning>
        {children}
      </body>
    </html>
  )
}
```

**In login page form:**
```tsx
'use client'

export default function LoginPage() {
  // ... existing code

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="space-y-2">
        {/* Disable browser autofill icons */}
        <input
          type="email"
          id="email"
          autoComplete="email"
          data-form-type="login"  {/* Helps extensions identify form type */}
          // ... rest of props
        />
      </div>
      {/* ... rest of form */}
    </form>
  )
}
```

---

### Step 3: Complete Patient Portal Screens

**Priority order (build these in React):**

1. **Dashboard** (`/patient/dashboard/page.tsx`)
   - Vitals summary cards (HR, BP, HRV, glucose, weight, BMI)
   - Recent trends chart
   - Today's tasks checklist
   - Next appointment card
   - Messages preview
   - Care plan progress

2. **Analytics** (`/patient/analytics/page.tsx`)
   - Time range selector (7d, 30d, 90d, 1y)
   - Vital trends charts (Recharts library)
   - HRV trend with recovery score
   - Stress meter visualization
   - Sleep quality chart
   - Activity/steps chart
   - BMI progress

3. **Messages** (`/patient/messages/page.tsx`)
   - Thread list (inbox)
   - Active conversation view
   - Message composer
   - Attachment support
   - Real-time updates

4. **Schedule** (`/patient/schedule/page.tsx`)
   - Upcoming appointments list
   - Book new appointment button
   - Virtual visit join button
   - Walk-in request form
   - Past appointments

5. **Profile** (`/patient/profile/page.tsx`)
   - Profile info editor
   - Connected devices
   - Health data sync settings
   - Notification preferences
   - Insurance information
   - Billing & payment

**Use this component pattern:**

```tsx
// Example: /src/app/patient/dashboard/page.tsx
'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { VitalsCard } from '@/components/patient/VitalsCard'
import { TrendsChart } from '@/components/patient/TrendsChart'
import { TasksList } from '@/components/patient/TasksList'
import { apiClient } from '@/lib/api/client'

export default function PatientDashboard() {
  const [vitals, setVitals] = useState(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    async function loadData() {
      try {
        const data = await apiClient.getPatientDashboard()
        setVitals(data)
      } catch (error) {
        console.error('Failed to load dashboard:', error)
      } finally {
        setLoading(false)
      }
    }
    loadData()
  }, [])

  if (loading) return <LoadingSpinner />

  return (
    <div className="p-6 space-y-6">
      <h1 className="text-3xl font-bold">Welcome back, Sarah</h1>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <VitalsCard title="Heart Rate" value={vitals.heartRate} />
        <VitalsCard title="HRV" value={vitals.hrv} />
        <VitalsCard title="Blood Pressure" value={vitals.bloodPressure} />
        {/* More cards... */}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Trends</CardTitle>
        </CardHeader>
        <CardContent>
          <TrendsChart data={vitals.trends} />
        </CardContent>
      </Card>

      <TasksList tasks={vitals.todayTasks} />
    </div>
  )
}
```

---

### Step 4: Complete Clinician Portal Screens

**Priority order:**

1. **Dashboard** (`/clinician/dashboard/page.tsx`)
   - High-risk patient alerts
   - Today's schedule
   - Pending tasks
   - Recent messages
   - Visit requests

2. **Patient List** (`/clinician/patients/page.tsx`)
   - Searchable/filterable table
   - Status indicators
   - Quick actions

3. **Patient Detail** (`/clinician/patients/[id]/page.tsx`)
   - Patient header (photo, name, DOB, MRN)
   - Tabs: Overview, Vitals, Care Plan, Messages, Notes, Labs
   - Vitals timeline with charts
   - Recent activity feed
   - Quick actions (message, schedule, orders)

4. **Virtual Visit** (`/clinician/visit/[id]/page.tsx`)
   - 3-column layout:
     - Left: Video feed (Twilio placeholder)
     - Center: Patient vitals/charts
     - Right: Visit notes, orders, chat
   - Visit timer
   - Recording controls
   - End visit workflow

5. **Tasks** (`/clinician/tasks/page.tsx`)
   - Task list with filters
   - Priority sorting
   - Assignment to team members
   - Task detail drawer

6. **Messages** (`/clinician/messages/page.tsx`)
   - Inbox with patient threads
   - Unread count badges
   - Message composer
   - Attachment handling

---

### Step 5: Shared Components

**Create reusable components in** `/src/components/shared/`:

```tsx
// LoadingSpinner.tsx
export function LoadingSpinner() {
  return <div className="animate-spin ...">...</div>
}

// ErrorBoundary.tsx
export function ErrorBoundary({ error, reset }) {
  return <div>Error: {error.message} <button onClick={reset}>Try again</button></div>
}

// EmptyState.tsx
export function EmptyState({ title, description, action }) {
  return <div className="text-center">...</div>
}

// DataTable.tsx (for patient lists, lab results)
export function DataTable<T>({ columns, data, ... }) {
  // Reusable table with sorting, filtering, pagination
}
```

---

## 🎨 DESIGN SYSTEM

### Colors (Already Defined)

```css
/* globals.css */
:root {
  --primary: 174 71% 44%;        /* Teal #00A67E */
  --secondary: 199 87% 56%;      /* Blue #0066CC */
  --accent: 188 100% 42%;        /* Teal accent #00B8D4 */
  --background: 210 40% 98%;     /* Light background #F8FAFC */
  --foreground: 215 16% 37%;     /* Text #475569 */
  --card: 0 0% 100%;             /* White cards */
  --success: 142 71% 45%;        /* Green #10B981 */
  --warning: 38 92% 50%;         /* Amber #F59E0B */
  --destructive: 0 72% 51%;      /* Red #DC2626 */
}
```

### Typography

```css
/* Use Inter font (already in globals.css) */
body {
  font-family: var(--font-inter), system-ui, -apple-system, sans-serif;
}

h1 { @apply text-3xl font-bold tracking-tight; }
h2 { @apply text-2xl font-semibold; }
h3 { @apply text-xl font-semibold; }
```

### Component Style Guidelines

**Cards:**
- Rounded: `rounded-xl`
- Shadow: `shadow-sm`
- Padding: `p-6`
- Border: Optional `border border-border`

**Buttons:**
- Primary: Teal background, white text
- Secondary: White background, border, teal text
- Sizes: `default`, `sm`, `lg`
- States: hover, active, disabled

**Charts:**
- Use Recharts library
- Colors from design system
- Responsive containers
- Tooltips with detailed data
- Axis labels clear and readable

---

## 🔌 API Integration

### API Client Setup

**File:** `/src/lib/api/client.ts`

```typescript
class APIClient {
  private baseURL: string
  private token: string | null = null

  constructor() {
    this.baseURL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3000'
  }

  setToken(token: string) {
    this.token = token
    if (typeof window !== 'undefined') {
      localStorage.setItem('auth_token', token)
    }
  }

  async request<T>(
    endpoint: string,
    options: RequestInit = {}
  ): Promise<T> {
    const headers = {
      'Content-Type': 'application/json',
      ...(this.token && { Authorization: `Bearer ${this.token}` }),
      ...options.headers,
    }

    const response = await fetch(`${this.baseURL}${endpoint}`, {
      ...options,
      headers,
    })

    if (!response.ok) {
      throw new APIError(response.status, await response.text())
    }

    return response.json()
  }

  // Patient endpoints
  async getPatientDashboard() {
    return this.request<DashboardData>('/api/patient/dashboard')
  }

  async getVitals(timeRange?: string) {
    return this.request<Vital[]>(`/api/vitals?range=${timeRange || '30d'}`)
  }

  async logVital(vital: VitalInput) {
    return this.request<Vital>('/api/vitals', {
      method: 'POST',
      body: JSON.stringify(vital),
    })
  }

  // Clinician endpoints
  async getClinicianDashboard() {
    return this.request<ClinicianDashboard>('/api/clinician/dashboard')
  }

  async getPatientList(filters?: PatientFilters) {
    const params = new URLSearchParams(filters as any).toString()
    return this.request<Patient[]>(`/api/clinician/patients?${params}`)
  }

  async getPatientDetail(patientId: string) {
    return this.request<PatientDetail>(`/api/clinician/patients/${patientId}`)
  }
}

export const apiClient = new APIClient()
```

---

## ✅ ACCEPTANCE CRITERIA

### When This Is Complete:

1. ✅ No Builder.io dependencies in package.json
2. ✅ No hydration errors in browser console
3. ✅ Login page works (authenticate with backend)
4. ✅ Patient dashboard loads with real data
5. ✅ All 5 patient screens functional
6. ✅ All 6 clinician screens functional
7. ✅ Shared components reusable
8. ✅ Design system consistently applied
9. ✅ API integration working
10. ✅ Responsive on mobile/tablet/desktop

---

## 🚫 WHAT NOT TO DO

**DO NOT:**
- ❌ Create Builder.io models or CMS content
- ❌ Use BuilderPage or BuilderComponent
- ❌ Mix CMS rendering with React pages
- ❌ Generate any patient pages until this doc is followed
- ❌ Create duplicate component structures
- ❌ Use any Builder.io SDK methods

---

## 📞 REPORTING

### After Each Major Step, Report:

```markdown
✅ Step [N] Complete: [Description]
- Files modified: [list]
- New components created: [list]
- API endpoints wired: [list]
- Screenshots: [if applicable]
- Next step: [what's next]
```

### If Blocked:

```markdown
🚫 BLOCKED on Step [N]: [Description]
- Issue: [what's wrong]
- Attempted solutions: [what you tried]
- Need: [what's required to proceed]
```

---

## 🎯 START COMMAND FOR CURSOR

**When ready to execute:**

```
Begin MyHealthAlly web cleanup and implementation:

1. Remove Builder.io dependencies
2. Fix login page hydration errors
3. Build patient portal screens (5 screens)
4. Build clinician portal screens (6 screens)
5. Create shared component library
6. Wire up API client
7. Test all functionality

Follow the architecture in: MYHEALTHALLY_WEB_ARCHITECTURE.md

Report after each major milestone.

DO NOT generate any patient pages until Steps 1-2 are complete.
DO NOT use Builder.io for any app features.
```

---

**This is the definitive web architecture. No more confusion. No more Builder.io debates. Just clean React/Next.js code. 🚀**
