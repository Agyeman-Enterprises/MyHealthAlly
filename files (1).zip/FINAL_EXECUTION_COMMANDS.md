# 🚀 MYHEALTHALLY - FINAL EXECUTION COMMANDS

**Date:** November 23, 2025  
**Status:** AUTHORIZED TO EXECUTE  
**Authority:** HIGHEST - SUPERSEDES ALL PREVIOUS SPECS

---

## 🎨 FINAL VERIFIED COLORS (PIXEL-SAMPLED)

```
Primary Aqua-Teal:    #39C6B3  ✅ VERIFIED
Primary Dark:         #2AA494
Primary Light:        #D7F4F0

Gradient Start:       #1FBCA9
Gradient End:         #0D8A77

Accent Green:         #12A38A
Accent Coral:         #F06D41

Background:           #F3F8F7
Surface:              #FFFFFF
Border:               #DCE5E3

Text Primary:         #0D3B36
Text Secondary:       #4E6F6A
Text Muted:           #8BA7A2

Success:              #12A38A
Warning:              #F4A024
Danger:               #E15555
Info:                 #39C6B3
```

---

## 📋 WHAT TO BUILD

### Patient App (24 Screens)
1. Login
2. Registration
3. OTP Verification
4. Forgot Password
5. Onboarding
6. Dashboard (with BMI card)
7. Vitals Trends (with BMI graph)
8. Daily Check-In (dynamic metrics)
9. Intake/Health History
10. Care Plan
11. Visit Summary
12. Emergency Info
13. Labs - Orders tab
14. Labs - Results tab
15. Lab Detail
16. Messages List
17. Message Thread + AI Assistant
18. Notifications
19. Schedule Overview
20. Book Appointment
21. Walk-In Request
22. Profile
23. Insurance Info
24. Billing & Invoices
25. Payment Methods
26. Connected Devices
27. Referrals & Documents
28. Support (WebView)

### Clinician Portal (9 Screens)
29. Clinician Dashboard
30. Patient List
31. Patient Detail
32. Care Plan Editor
33. Lab Order Creator
34. Referral Creator
35. Document Creator
36. Triage Queue
37. Visit Queue

### Ohimaa Content Engine (8 Sections)
38. Programs
39. Stress Management
40. Sleep Programs
41. GI Reset
42. Detox Programs
43. Meal Plans
44. Exercise Library
45. Educational Resources

**Total:** 45 complete sections across 3 subsystems

---

## 💻 COMMAND 1: CURSOR (WEB PLATFORM)

### Copy and paste this EXACTLY into Cursor:

```
CURSOR: IMPLEMENT THE FULL MYHEALTHALLY WEB APP USING THE UNIFIED TEAL THEME.

CRITICAL - READ THESE FILES FIRST:
1. theme.json - Design tokens (FINAL colors)
2. FINAL_MASTER_EXECUTION_PACKAGE.md - Complete spec

PRIMARY COLOR: #39C6B3 (Aqua-Teal) - VERIFIED BY PIXEL SAMPLING
Border Radius: 6px EVERYWHERE
Typography: Inter/Roboto, 16px body, 600 weight headers
Shadows: Soft (0px 1px 3px rgba(0,0,0,0.08))

FILE STRUCTURE - CREATE EXACTLY:
myhealthally/
├── theme.json
├── src/
│   ├── theme/
│   │   ├── tokens.ts
│   │   ├── global.css
│   │   ├── components.css
│   │   ├── palette.ts
│   │   └── typography.ts
│   ├── components/
│   │   ├── ui/ (Card, Button, Input, Tabs, Avatar, Chip)
│   │   ├── layout/ (PageContainer, Grid, Row, Column)
│   │   ├── widgets/ (VitalCard, LabCard, AppointmentCard, MessageThreadPreview, GraphContainer)
│   │   └── charts/ (LineChart, TrendChart, BarChart)
│   ├── api/
│   │   ├── http.ts
│   │   ├── patient.ts
│   │   ├── labs.ts
│   │   ├── metrics.ts
│   │   ├── referrals.ts
│   │   ├── documents.ts
│   │   ├── appointments.ts
│   │   └── clinician.ts
│   ├── patient/ (24 patient pages)
│   │   ├── Dashboard/
│   │   ├── Analytics/
│   │   ├── Messages/
│   │   ├── Profile/
│   │   │   ├── Referrals.tsx
│   │   │   └── Documents.tsx
│   │   ├── Schedule/
│   │   ├── Labs/
│   │   │   ├── LabOrders.tsx
│   │   │   └── LabResults.tsx
│   │   ├── Intake/
│   │   └── CheckIn/
│   ├── clinician/ (9 clinician screens)
│   │   ├── Dashboard/
│   │   ├── Patients/
│   │   ├── CarePlans/
│   │   ├── Labs/
│   │   ├── Referrals/
│   │   ├── Documents/
│   │   ├── Triage/
│   │   └── VisitQueue/
│   └── content/ (Ohimaa Content Engine)
│       ├── Programs/
│       ├── MealPlans/
│       ├── Exercises/
│       └── Support/

TASKS:
1. Remove ALL Builder.io artifacts
2. Create theme system with exact colors above
3. Build all 24 patient screens
4. Build all 9 clinician screens
5. Build Ohimaa content engine (8 sections)
6. Implement BMI tracking (card + graph)
7. Implement dynamic metrics system
8. Implement lab orders + results (separate tabs)
9. Implement referrals page
10. Implement documents page

API ENDPOINTS TO USE:
GET  /patients/me/metrics-config
POST /patients/me/checkins
GET  /patients/me/bmi/history
GET  /patients/me/bmi/latest
GET  /patients/me/labs/orders
GET  /patients/me/labs/results
GET  /patients/me/referrals
GET  /patients/me/documents
POST /clinician/referrals
POST /clinician/documents
POST /clinician/labs/orders

TIMELINE:
Day 1: Theme system + base components
Day 2-3: Patient pages
Day 4-5: Clinician portal
Day 6: Ohimaa content engine
Day 7: Testing + polish

REPORT PROGRESS AFTER EACH DAY.

START NOW. NO DEVIATIONS.
```

---

## 📱 COMMAND 2: CLAUDE/HENRY (MOBILE - iOS + ANDROID)

### Copy and paste this EXACTLY:

```
CLAUDE: USE THE UNIFIED TEAL THEME (#39C6B3).

CRITICAL - THIS IS THE FINAL MASTER SPEC:
- Primary Color: #39C6B3 (Aqua-Teal)
- Primary Dark: #2AA494
- Primary Light: #D7F4F0
- Gradient: #1FBCA9 to #0D8A77
- Accent Green: #12A38A
- Accent Coral: #F06D41
- Background: #F3F8F7
- Text Primary: #0D3B36
- Border Radius: 6px everywhere
- Typography: Inter/SF Pro, 16px body

IMPLEMENT 24 PATIENT SCREENS + CLINICIAN FEATURES:

Auth & Onboarding (5):
1. Login
2. Registration
3. OTP Verification
4. Forgot Password
5. Onboarding/Welcome

Home Tab (6):
6. Patient Dashboard (BMI card)
7. Daily Check-in (dynamic metrics)
8. Intake/Health History
9. Care Plan
10. Visit Summary
11. Emergency Info

Insights Tab (3):
12. Vitals & Trends (BMI graph)
13. Labs (Orders + Results tabs)
14. Lab Detail

Messages Tab (3):
15. Messages List
16. Message Thread + AI Assistant
17. Notifications Center

Schedule Tab (3):
18. Schedule Overview
19. Appointment Booking
20. Walk-In Request

Profile Tab (6):
21. Profile & Settings
22. Insurance Info
23. Billing & Invoices
24. Payment Methods
25. Connected Devices
26. Referrals & Documents
27. Support (WebView)

PLATFORM-SPECIFIC BRANDING:
MyHealthAlly iOS/Android: #39C6B3 (Aqua-Teal)
Lina'la iOS/Android: #006B5C (Logo Teal), #FF8B7A (Coral)

OHIMAA CONTENT VIA WEBVIEW:
- Programs, Meal Plans, Exercises, Stress, Resources
- URL: OHIMAA_CONTENT_BASE_URL + "/programs?token={jwt}"
- DO NOT build natively

BMI TRACKING:
- Height stored once
- Weight logged daily
- Auto-calculate: weight_kg / (height_m)²
- Show on Dashboard + Vitals graph
- GLP-1 context when active

DYNAMIC METRICS:
- Fetch metrics_config from backend
- Render form fields dynamically
- Support adding new metrics without app update

LAB ORDERS + RESULTS:
- Orders tab: Show status (Ordered → Awaiting Sample → In Progress → Completed)
- Results tab: Show values with ranges, flag abnormals

REFERRALS:
- List specialist/PT/imaging referrals
- Show status, contact info
- Download PDF, call specialist

DOCUMENTS:
- Medical letters, excuse notes
- Work/school excuses, RTW clearance, travel letters
- View/download/share PDFs

API ENDPOINTS:
GET  /patients/me/metrics-config
POST /patients/me/checkins
GET  /patients/me/bmi/history
GET  /patients/me/bmi/latest
GET  /patients/me/labs/orders
GET  /patients/me/labs/results
GET  /patients/me/referrals
GET  /patients/me/documents

MATCH WEB COMPONENTS:
- Card, Button, Input, Tabs, Avatar, Chip
- VitalCard, LabCard, AppointmentCard
- Use exact same spacing (4/8/12/16/24/32)
- Use exact same shadows (soft, subtle)
- Use exact same typography scale

DELIVERABLES:
1. SwiftUI theme pack (UIColors, spacing, radius)
2. Jetpack Compose theme pack (Color, Dp, Shape)
3. All 24 screens implemented
4. WebView for Ohimaa content
5. Full API integration

TIMELINE:
Week 1: Lina'la iOS (24 screens)
Week 2: MyHealthAlly iOS (clone + rebrand)
Week 3: Lina'la Android (24 screens)
Week 4: MyHealthAlly Android (clone + rebrand)

START NOW. NO DEVIATIONS.
```

---

## 🔧 COMMAND 3: HENRY (IMMEDIATE - iOS BACKEND INTEGRATION)

### Copy and paste this EXACTLY:

```
HENRY: INTEGRATE LINA'LA iOS WITH BACKEND NOW.

FILES TO USE:
1. iOS_APIService.swift
2. iOS_AuthenticationManager_Updated.swift
3. iOS_ViewModels_Updated.swift
4. iOS_Colors_Updated.swift (use LOGO colors: #006B5C teal, #FF8B7A coral)
5. iOS_BACKEND_INTEGRATION_GUIDE.md

BACKEND: http://localhost:3000

CRITICAL COLORS FOR LINA'LA:
- Primary Teal: #006B5C (from logo)
- Accent Coral: #FF8B7A (from logo)
- Turquoise: #45B5AA (from logo)
NOT the MyHealthAlly colors (#39C6B3)

TASKS (1-2 HOURS):
1. Replace mock data with APIService calls
2. Test login/register
3. Test dashboard data loading
4. Test vitals syncing
5. Test messaging

ENDPOINTS TO TEST:
POST /auth/login
POST /auth/register
GET  /patients/me
GET  /patients/me/dashboard
GET  /patients/me/vitals
POST /patients/me/vitals
GET  /patients/me/messages

SUCCESS CRITERIA:
✅ Login works with backend
✅ Dashboard loads real patient data
✅ Vitals sync to backend
✅ Messages send/receive
✅ No errors in console
✅ App uses logo colors (#006B5C, #FF8B7A)

REPORT WHEN DONE OR IF STUCK.

START NOW.
```

---

## ✅ SUCCESS CRITERIA (ALL PLATFORMS)

### Web (Cursor)
- [ ] Primary color #39C6B3 everywhere
- [ ] 6px border radius everywhere
- [ ] All 24 patient screens built
- [ ] All 9 clinician screens built
- [ ] Ohimaa content engine built (8 sections)
- [ ] BMI card + graph functional
- [ ] Dynamic metrics system working
- [ ] Lab orders + results (separate tabs)
- [ ] Referrals page functional
- [ ] Documents page functional
- [ ] No Builder.io artifacts
- [ ] Fully responsive
- [ ] Matches design system exactly

### Mobile (Claude/Henry)
- [ ] All 24 core screens built
- [ ] MyHealthAlly uses #39C6B3 (Aqua-Teal)
- [ ] Lina'la uses #006B5C + #FF8B7A (Logo colors)
- [ ] BMI tracking functional
- [ ] Dynamic metrics working
- [ ] Lab orders + results functional
- [ ] Referrals functional
- [ ] Documents functional
- [ ] Ohimaa content via WebView
- [ ] Backend integration complete
- [ ] Matches web UI exactly

---

## 📦 FILES AVAILABLE

### For Cursor:
1. **[theme.json](computer:///mnt/user-data/outputs/theme.json)** - Updated with #39C6B3
2. **FINAL_MASTER_EXECUTION_PACKAGE.md** (this document)

### For Claude/Henry:
1. **[iOS_APIService.swift](computer:///mnt/user-data/outputs/iOS_APIService.swift)**
2. **[iOS_AuthenticationManager_Updated.swift](computer:///mnt/user-data/outputs/iOS_AuthenticationManager_Updated.swift)**
3. **[iOS_ViewModels_Updated.swift](computer:///mnt/user-data/outputs/iOS_ViewModels_Updated.swift)**
4. **[iOS_Colors_Updated.swift](computer:///mnt/user-data/outputs/iOS_Colors_Updated.swift)**
5. **[iOS_BACKEND_INTEGRATION_GUIDE.md](computer:///mnt/user-data/outputs/iOS_BACKEND_INTEGRATION_GUIDE.md)**
6. **[MOBILE_ARCHITECTURE_CORRECTED.md](computer:///mnt/user-data/outputs/MOBILE_ARCHITECTURE_CORRECTED.md)**

---

## 🎯 EXECUTION ORDER

1. **Give Command 3 to Henry** (RIGHT NOW - 1-2 hours)
2. **Give Command 1 to Cursor** (RIGHT NOW - 1 week)
3. **Give Command 2 to Claude** (After Lina'la iOS integration - 4 weeks)

---

## 🚨 CRITICAL REMINDERS

**NO DEVIATIONS:**
- Primary color is #39C6B3 (verified by pixel sampling)
- Border radius is 6px (not 24px, not 28px)
- 24 patient screens (not 36, not 20)
- Lina'la uses LOGO colors (#006B5C, #FF8B7A)
- MyHealthAlly uses #39C6B3 everywhere
- All platforms match exactly

**THIS SUPERSEDES:**
- All previous color specs
- All previous screen counts
- All previous border radius specs
- All previous file trees
- Everything

---

# ✅ READY TO EXECUTE

**Copy the three commands above and send them:**
- Command 1 → Cursor
- Command 2 → Claude (for full mobile build)
- Command 3 → Henry (for immediate iOS integration)

**Then wait for reports. No more planning. Just execution.**

# 🚀 GO! GO! GO!
