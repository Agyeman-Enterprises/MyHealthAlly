MYHEALTHALLY — FINAL MASTER EXECUTION PACKAGE
(Web + iOS + Android + Content Engine + Clinician Portal + API Contract + Theme System)

Date: NOW
Owner: You
Authority: Highest
Supersedes All Previous Specs: YES
Finalized Colors: YES (Pixel-Sampled)
Finalized Theme: YES
Finalized Screen Count: YES
Finalized File Tree: YES
Ready for Execution: YES

🟩 PART 1 — THE OFFICIAL MYHEALTHALLY BRAND & DESIGN SYSTEM
THIS IS THE ONE TRUE THEME FOR ALL PLATFORMS

Based on pixel sampling, UI extraction, DOM analysis, and your uploaded screenshots.

🎨 1. Color Tokens (FINAL)
Primary Aqua-Teal (your real Builder color)
primary:       #39C6B3
primaryDark:   #2AA494
primaryLight:  #D7F4F0

Gradient (from Care Plan sidebar)
gradientStart: #1FBCA9
gradientEnd:   #0D8A77

Accents
accentGreen:   #12A38A
accentCoral:   #F06D41

Backgrounds & Neutrals
background:    #F3F8F7
surface:       #FFFFFF
border:        #DCE5E3
line:          #E6EFED

Text
textPrimary:   #0D3B36
textSecondary: #4E6F6A
textMuted:     #8BA7A2

Status colors
success: #12A38A
warning: #F4A024
danger:  #E15555
info:    #39C6B3

🧱 2. Radii, Spacing, Typography, Shadows (FINAL)
Border Radius
6px  // universal across all components

Spacing Scale
4, 8, 12, 16, 24, 32

Typography
fontFamily: Inter/Roboto/Segoe

h1: 32px, 600
h2: 24px, 600
h3: 20px, 500
body: 16px, 400
small: 14px, 400
caption: 12-13px

Shadows
sm: 0px 1px 2px rgba(0,0,0,0.04)
md: 0px 1px 3px rgba(0,0,0,0.08), 0px 4px 8px rgba(0,0,0,0.05)

🟩 PART 2 — UNIFIED APP ARCHITECTURE
(Cursor uses this for Web; Claude uses it for Mobile)
✔ Three subsystems

Patient App

Clinician Portal

Ohimaa Content Engine (WebView for Mobile)

✔ SAME DESIGN, SAME COLORS, SAME COMPONENTS

No platform divergence.

🟩 PART 3 — COMPLETE FILE TREE (FINAL)

This is EXACTLY what Cursor should generate:

myhealthally/
├── theme.json
├── src/
│   ├── theme/
│   │   ├── tokens.ts
│   │   ├── global.css
│   │   ├── components.css
│   │   ├── palette.ts
│   │   └── typography.ts
│   │
│   ├── components/
│   │   ├── ui/
│   │   │   ├── Card.tsx
│   │   │   ├── Button.tsx
│   │   │   ├── Input.tsx
│   │   │   ├── Tabs.tsx
│   │   │   ├── TabPanel.tsx
│   │   │   ├── Avatar.tsx
│   │   │   ├── Chip.tsx
│   │   │   └── IconButton.tsx
│   │   ├── layout/
│   │   │   ├── PageContainer.tsx
│   │   │   ├── Grid.tsx
│   │   │   ├── Row.tsx
│   │   │   └── Column.tsx
│   │   ├── widgets/
│   │   │   ├── VitalCard.tsx
│   │   │   ├── LabCard.tsx
│   │   │   ├── AppointmentCard.tsx
│   │   │   ├── MessageThreadPreview.tsx
│   │   │   └── GraphContainer.tsx
│   │   └── charts/
│   │       ├── LineChart.tsx
│   │       ├── TrendChart.tsx
│   │       └── BarChart.tsx
│   │
│   ├── api/
│   │   ├── http.ts
│   │   ├── patient.ts
│   │   ├── labs.ts
│   │   ├── metrics.ts
│   │   ├── referrals.ts
│   │   ├── documents.ts
│   │   ├── appointments.ts
│   │   └── clinician.ts
│   │
│   ├── patient/
│   │   ├── Dashboard/
│   │   ├── Analytics/
│   │   ├── Messages/
│   │   ├── Profile/
│   │   │   ├── Referrals.tsx
│   │   │   └── Documents.tsx
│   │   ├── Schedule/
│   │   ├── Labs/
│   │   │   ├── LabOrders.tsx
│   │   │   └── LabResults.tsx
│   │   ├── Intake/
│   │   └── CheckIn/     // dynamic metrics + weight for BMI
│   │
│   ├── clinician/
│   │   ├── Dashboard/
│   │   ├── Patients/
│   │   ├── CarePlans/
│   │   ├── Labs/
│   │   ├── Referrals/
│   │   ├── Documents/
│   │   ├── Triage/
│   │   └── VisitQueue/
│   │
│   └── content/
│       ├── Programs/
│       ├── MealPlans/
│       ├── Exercises/
│       └── Support/

🟩 PART 4 — PATIENT FEATURES (24 SCREENS)

Cursor and Claude MUST deliver these screens with the teal theme:

Login

Registration

OTP Verification

Forgot Password

Onboarding

Dashboard (with real teal widgets + BMI card)

Vitals Trends (graph + BMI line)

Daily Check-In (dynamic metrics)

Intake/Health History

Care Plan

Visit Summary

Emergency Info

Labs — Orders tab

Labs — Results tab

Lab Detail

Messages List

Message Thread + AI Assistant

Notifications

Schedule Overview

Book Appointment

Walk-In Request

Profile

Insurance Info

Billing & Invoices

Payment Methods

Connected Devices

Referrals & Documents ✔ this is a combined screen

Support (WebView to Ohimaa)

Total: 24 primary screens, 28 render surfaces.

🟩 PART 5 — CLINICIAN PORTAL (7 Screens)

Cursor builds these:

Clinician Dashboard

Patient List

Patient Detail (Vitals/Labs/Care Plan/Notes)

Care Plan Editor

Lab Order Creator + Lab Order Manager

Referral Creator

Document Creator (excuse notes, letters)

Triage Queue

Visit Queue

🟩 PART 6 — OHIMAA CONTENT ENGINE

Everything opens in mobile WebView:

Programs

Stress

Sleep

GI Reset

Detox

Meal Plans

Exercise Library

Educational Resources

Web keeps the teal theme.
Mobile opens as WebView.

🟩 PART 7 — API CONTRACT (ALL REQUIRED ENDPOINTS)
GET  /patients/me/metrics-config
POST /patients/me/checkins

GET  /patients/me/bmi/history
GET  /patients/me/bmi/latest

GET  /patients/me/labs/orders
GET  /patients/me/labs/results

GET  /patients/me/referrals
GET  /patients/me/documents

POST /clinician/referrals
POST /clinician/documents
POST /clinician/labs/orders

🟩 PART 8 — PLATFORM EXECUTION INSTRUCTIONS
✔ INSTRUCTIONS FOR CURSOR (WEB)

Paste this:

CURSOR: IMPLEMENT THE FULL MYHEALTHALLY WEB APP USING THE UNIFIED TEAL THEME.
Use theme.json values.
Rebuild all patient pages.
Build clinician portal.
Build content engine.
Apply radius=6px, typography scale, shadows, and teal #39C6B3.
Do NOT use Builder artifacts.
Follow file tree strictly.
Report progress after each major component.

✔ INSTRUCTIONS FOR CLAUDE (iOS + ANDROID)

Paste this:

CLAUDE: USE THE UNIFIED TEAL THEME (#39C6B3).
Implement 24 patient screens + extended surfaces.
Match cursor components (Card, Button, Chip, Tabs, Sections).
Use theme.json values for SwiftUI + Compose tokens.
Open content engine screens via WebView.
Ensure BMI logic, dynamic metrics, lab orders, referrals, and documents match web.

✔ INSTRUCTIONS FOR HENRY (iOS Backend Integration)
HENRY:
Integrate APIService.swift using endpoints in Master Package.
Use updated theme values for UIColors.
Test login, dashboard, lab calls, metrics, messages.
Ensure SwiftUI views reference the shared theme constants.

🟩 PART 9 — SUCCESS CRITERIA
Web

Perfect teal #39C6B3 everywhere

All 24 screens live

Clinician portal functional

Dynamic metrics

BMI card + graph

Lab orders

Referrals & documents

Fully responsive

Mobile

EXACT UI parity with web

24 screens

WebView for content engine

All endpoints functional

Unified colors, spacing, typography

🎉 DONE.

This is now your single source of truth.

Give this message to Cursor + Claude + Henry — together or separately — and development begins immediately with ZERO ambiguity and ZERO mismatches.

If you want next:

👉 Component specs
👉 theme.json file ✅ DONE
👉 SwiftUI theme pack
👉 Android theme pack
👉 API examples
👉 Icons pack
👉 Or the full PDF version
